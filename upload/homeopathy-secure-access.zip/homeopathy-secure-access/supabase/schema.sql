-- Homeopathy Secure Access Schema
-- Run this in Supabase SQL Editor.

create extension if not exists pgcrypto;

create table if not exists public.app_users (
  id uuid primary key references auth.users(id) on delete cascade,
  name text not null,
  email text not null unique,
  mobile text,
  access_pin_hash text not null,
  role text not null default 'user' check (role in ('admin', 'user')),
  status text not null default 'active' check (status in ('active', 'blocked')),
  access_expiry date,
  device_limit int default 1,
  pin_failed_attempts int not null default 0,
  pin_locked_until timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  last_login timestamptz
);

create table if not exists public.access_permissions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.app_users(id) on delete cascade,
  can_access_books boolean not null default true,
  can_access_remedies boolean not null default true,
  can_access_notes boolean not null default true,
  can_copy boolean not null default false,
  can_download boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(user_id)
);

create table if not exists public.login_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.app_users(id) on delete set null,
  ip_address text,
  device_info text,
  login_status text not null check (login_status in ('success', 'failed')),
  failure_reason text,
  created_at timestamptz not null default now()
);

create table if not exists public.pin_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.app_users(id) on delete set null,
  ip_address text,
  device_info text,
  pin_status text not null check (pin_status in ('success', 'failed', 'locked', 'reset')),
  failure_reason text,
  created_at timestamptz not null default now()
);

create table if not exists public.remedies (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  source text not null,
  summary text,
  content jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists app_users_email_idx on public.app_users(email);
create index if not exists app_users_role_idx on public.app_users(role);
create index if not exists app_users_status_idx on public.app_users(status);
create index if not exists remedies_name_idx on public.remedies(name);
create index if not exists remedies_source_idx on public.remedies(source);
create index if not exists login_logs_created_idx on public.login_logs(created_at desc);
create index if not exists pin_logs_created_idx on public.pin_logs(created_at desc);

alter table public.app_users enable row level security;
alter table public.access_permissions enable row level security;
alter table public.login_logs enable row level security;
alter table public.pin_logs enable row level security;
alter table public.remedies enable row level security;

-- No public client policies for remedies.
-- Access is done through server-side code after login + fixed PIN verification.
-- Admin service key bypasses RLS on the server only.

create policy "users can read own profile"
on public.app_users for select
to authenticated
using (auth.uid() = id);

create policy "users can read own permissions"
on public.access_permissions for select
to authenticated
using (auth.uid() = user_id);

insert into public.remedies (name, source, summary, content)
values (
  'Aconitum Napellus',
  'Boericke',
  'Sudden onset, fear, restlessness, fever after exposure to cold dry wind.',
  '{
    "Mind": "Great fear, anxiety, and worry accompany every ailment. Fear of death. Restlessness and tossing about.",
    "Generals": "Complaints come suddenly and violently. Worse after cold dry wind. Useful in early stages of acute conditions.",
    "Head": "Fullness, heavy feeling, hot face, throbbing headache with anxiety.",
    "Fever": "High fever with dry skin, thirst, restlessness, and fear.",
    "Modalities": "Worse at night, from cold dry wind, fright, shock. Better in open air.",
    "Dose": "Use according to practitioner judgment and case totality."
  }'::jsonb
)
on conflict do nothing;
