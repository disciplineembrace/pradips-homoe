-- FIRST ADMIN SETUP
-- 1) Create an auth user manually in Supabase Dashboard > Authentication > Users.
-- 2) Copy that user's UUID.
-- 3) Generate a bcrypt hash for a 6-digit PIN using the helper below or the app action.
--    Simple option: first create a temporary normal user from the app after configuring one admin.
--    For manual SQL, paste bcrypt hash value in access_pin_hash.

-- Example only; replace values.
insert into public.app_users (
  id,
  name,
  email,
  access_pin_hash,
  role,
  status,
  access_expiry,
  device_limit
) values (
  'PASTE_AUTH_USER_UUID_HERE',
  'Admin Name',
  'admin@example.com',
  'PASTE_BCRYPT_HASH_OF_6_DIGIT_PIN_HERE',
  'admin',
  'active',
  null,
  1
);
