'use client'

import { useActionState } from 'react'
import { changeUserPinAction, updateUserAction } from '@/app/actions/admin-users'
import { SubmitButton } from './SubmitButton'

type UserRecord = {
  id: string
  name: string
  email: string
  mobile: string | null
  role: 'admin' | 'user'
  status: 'active' | 'blocked'
  access_expiry: string | null
  device_limit: number | null
}

export function EditUserForm({ user }: { user: UserRecord }) {
  const [state, action] = useActionState(updateUserAction, {})
  return (
    <form className="form" action={action} style={{ maxWidth: 760 }}>
      <h2>Edit User</h2>
      {state.error && <div className="error">{state.error}</div>}
      <input type="hidden" name="userId" value={user.id} />
      <div className="field"><label>Full Name</label><input name="name" defaultValue={user.name} required /></div>
      <div className="field"><label>Email / Login ID</label><input value={user.email} disabled /></div>
      <div className="field"><label>Mobile Number</label><input name="mobile" defaultValue={user.mobile || ''} /></div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
        <div className="field"><label>Role</label><select name="role" defaultValue={user.role}><option value="user">User</option><option value="admin">Admin</option></select></div>
        <div className="field"><label>Status</label><select name="status" defaultValue={user.status}><option value="active">Active</option><option value="blocked">Blocked</option></select></div>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
        <div className="field"><label>Access Expiry</label><input name="accessExpiry" type="date" defaultValue={user.access_expiry || ''} /></div>
        <div className="field"><label>Device Limit</label><input name="deviceLimit" type="number" min={1} max={10} defaultValue={user.device_limit || 1} /></div>
      </div>
      <SubmitButton>Save Changes</SubmitButton>
    </form>
  )
}

export function ChangePinForm({ userId }: { userId: string }) {
  const [state, action] = useActionState(changeUserPinAction, {})
  return (
    <form className="form" action={action} style={{ maxWidth: 500, marginTop: 28 }}>
      <h2>Change Fixed PIN</h2>
      <p style={{ color: 'var(--muted)' }}>Only admin can change PIN. User cannot change or view it.</p>
      {state.error && <div className="error">{state.error}</div>}
      <input type="hidden" name="userId" value={userId} />
      <div className="field"><label>New 6-digit PIN</label><input name="accessPin" inputMode="numeric" pattern="[0-9]{6}" maxLength={6} required /></div>
      <SubmitButton>Change PIN</SubmitButton>
    </form>
  )
}
