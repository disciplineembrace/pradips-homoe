'use client'

import { useActionState } from 'react'
import { verifyPinAction } from '@/app/actions/auth'
import { SubmitButton } from './SubmitButton'

export function PinForm() {
  const [state, action] = useActionState(verifyPinAction, {})
  return (
    <form className="form" action={action}>
      {state.error && <div className="error">{state.error}</div>}
      <div className="field">
        <label>Fixed 6-digit Access PIN</label>
        <input
          name="pin"
          inputMode="numeric"
          pattern="[0-9]{6}"
          maxLength={6}
          minLength={6}
          placeholder="••••••"
          autoFocus
          required
        />
      </div>
      <SubmitButton>Verify PIN</SubmitButton>
    </form>
  )
}
