import Link from 'next/link'
import { logoutAction } from '@/app/actions/auth'

export function AdminShell({ children, adminName }: { children: React.ReactNode; adminName: string }) {
  return (
    <div className="admin-layout">
      <aside className="admin-sidebar">
        <h2>{process.env.NEXT_PUBLIC_SITE_NAME || "Pradip's Homoe"}</h2>
        <nav className="admin-nav">
          <Link href="/admin">Dashboard</Link>
          <Link href="/admin/users">Users</Link>
          <Link href="/admin/logs">Login & PIN Logs</Link>
          <Link href="/dashboard">Open Website</Link>
          <form action={logoutAction}><button type="submit">Logout</button></form>
        </nav>
      </aside>
      <main className="admin-main">
        <div className="admin-top">
          <div>
            <strong>Admin Panel</strong>
            <div style={{ color: 'var(--muted)', fontSize: 14 }}>Welcome, {adminName}</div>
          </div>
          <Link className="btn" href="/admin/users/create">Add User</Link>
        </div>
        {children}
      </main>
    </div>
  )
}
