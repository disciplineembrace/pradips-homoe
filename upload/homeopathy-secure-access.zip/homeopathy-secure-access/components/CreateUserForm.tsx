'use client'

import { useActionState } from 'react'
import { createUserAction } from '@/app/actions/admin-users'
import { SubmitButton } from './SubmitButton'

export function CreateUserForm() {
  const [state, action] = useActionState(createUserAction, {})
  return (
    <form className="form" action={action} style={{ maxWidth: 760 }}>
      {state.error && <div className="error">{state.error}</div>}
      <div className="field"><label>Full Name</label><input name="name" required /></div>
      <div className="field"><label>Email / Login ID</label><input name="email" type="email" required /></div>
      <div className="field"><label>Mobile Number</label><input name="mobile" /></div>
      <div className="field"><label>Password</label><input name="password" type="password" minLength={8} required /></div>
      <div className="field"><label>Fixed 6-digit Access PIN</label><input name="accessPin" inputMode="numeric" pattern="[0-9]{6}" maxLength={6} required /></div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
        <div className="field"><label>Role</label><select name="role" defaultValue="user"><option value="user">User</option><option value="admin">Admin</option></select></div>
        <div className="field"><label>Status</label><select name="status" defaultValue="active"><option value="active">Active</option><option value="blocked">Blocked</option></select></div>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
        <div className="field"><label>Access Expiry</label><input name="accessExpiry" type="date" /></div>
        <div className="field"><label>Device Limit</label><input name="deviceLimit" type="number" min={1} max={10} defaultValue={1} /></div>
      </div>
      <SubmitButton>Create User</SubmitButton>
    </form>
  )
}
