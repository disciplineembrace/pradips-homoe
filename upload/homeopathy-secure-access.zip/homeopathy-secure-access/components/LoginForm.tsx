'use client'

import { useActionState } from 'react'
import { loginAction } from '@/app/actions/auth'
import { SubmitButton } from './SubmitButton'

export function LoginForm() {
  const [state, action] = useActionState(loginAction, {})
  return (
    <form className="form" action={action}>
      {state.error && <div className="error">{state.error}</div>}
      <div className="field">
        <label>Login ID / Email</label>
        <input name="email" type="email" autoComplete="email" required />
      </div>
      <div className="field">
        <label>Password</label>
        <input name="password" type="password" autoComplete="current-password" required />
      </div>
      <SubmitButton>Login</SubmitButton>
    </form>
  )
}
