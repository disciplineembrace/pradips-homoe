Build a secure admin-created user access system for my existing homeopathic remedy website.

Do not change existing colors, branding, remedy data, or reading-screen theme. Add only authentication, admin panel, fixed PIN verification, access protection, and backend security.

Core requirement:
Only users created by admin can login. User logs in using Login ID/Email + Password. After password login, user must enter a fixed 6-digit Access PIN created by admin. The PIN is not OTP. Do not generate OTP. Do not add resend PIN. PIN change/reset must be available only to admin.

User cannot:
- Change PIN
- Reset PIN
- View PIN
- Request PIN
- Bypass PIN

Admin can:
- Create user
- Set Login ID/Email
- Set password
- Set fixed 6-digit PIN
- Change/reset PIN
- Unlock failed PIN attempts
- Block/unblock user
- Delete user
- Set role admin/user
- Set access expiry date
- View login logs
- View PIN logs

Security:
- Store passwords through Supabase Auth or secure password hashing.
- Store fixed PIN as hash only.
- Never store plain PIN.
- Never expose service/secret key to frontend.
- Use server-side checks for all protected data.
- Protect all private API endpoints.
- Enable RLS in Supabase.
- Do not expose remedy data in frontend bundle.
- After 3 wrong PIN attempts, lock PIN verification for 15 minutes.
- Add audit logs for login and PIN events.

Routes:
/login
/verify-pin
/dashboard
/remedy/[id]
/admin
/admin/users
/admin/users/create
/admin/users/[id]
/admin/logs

Final result:
Only admin-created users can access remedy data after password + fixed PIN verification. Admin alone controls PIN changes.
