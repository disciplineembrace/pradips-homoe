import { headers } from 'next/headers'
import { supabaseAdmin } from '@/lib/supabase/admin'

export async function getRequestMeta() {
  const h = await headers()
  const ip = h.get('x-forwarded-for')?.split(',')[0]?.trim() || h.get('x-real-ip') || 'unknown'
  const device = h.get('user-agent') || 'unknown'
  return { ip_address: ip, device_info: device }
}

export async function logLogin(userId: string | null, status: 'success' | 'failed', failure_reason?: string) {
  const meta = await getRequestMeta()
  await supabaseAdmin.from('login_logs').insert({
    user_id: userId,
    login_status: status,
    failure_reason: failure_reason || null,
    ...meta
  })
}

export async function logPin(userId: string, status: 'success' | 'failed' | 'locked' | 'reset', failure_reason?: string) {
  const meta = await getRequestMeta()
  await supabaseAdmin.from('pin_logs').insert({
    user_id: userId,
    pin_status: status,
    failure_reason: failure_reason || null,
    ...meta
  })
}
