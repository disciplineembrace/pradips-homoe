import { redirect } from 'next/navigation'
import { createClient } from '@/lib/supabase/server'
import { supabaseAdmin } from '@/lib/supabase/admin'
import { verifyPinSession } from '@/lib/session'

export type AppUser = {
  id: string
  name: string
  email: string
  mobile: string | null
  role: 'admin' | 'user'
  status: 'active' | 'blocked'
  access_expiry: string | null
  device_limit: number | null
  pin_failed_attempts: number
  pin_locked_until: string | null
}

export async function getCurrentAuthUser() {
  const supabase = await createClient()
  const { data, error } = await supabase.auth.getUser()
  if (error || !data.user) return null
  return data.user
}

export async function getAppUser(userId: string): Promise<AppUser | null> {
  const { data, error } = await supabaseAdmin
    .from('app_users')
    .select('*')
    .eq('id', userId)
    .single()

  if (error || !data) return null
  return data as AppUser
}

export function isExpired(accessExpiry: string | null) {
  if (!accessExpiry) return false
  const end = new Date(accessExpiry + 'T23:59:59')
  return Date.now() > end.getTime()
}

export async function requireLoggedInUser() {
  const authUser = await getCurrentAuthUser()
  if (!authUser) redirect('/login')

  const appUser = await getAppUser(authUser.id)
  if (!appUser) redirect('/login?error=profile-missing')
  if (appUser.status === 'blocked') redirect('/login?error=blocked')
  if (isExpired(appUser.access_expiry)) redirect('/login?error=expired')

  return { authUser, appUser }
}

export async function requireVerifiedUser() {
  const { authUser, appUser } = await requireLoggedInUser()
  const verified = await verifyPinSession(authUser.id)
  if (!verified) redirect('/verify-pin')
  return { authUser, appUser }
}

export async function requireAdmin() {
  const { authUser, appUser } = await requireVerifiedUser()
  if (appUser.role !== 'admin') redirect('/dashboard')
  return { authUser, appUser }
}
