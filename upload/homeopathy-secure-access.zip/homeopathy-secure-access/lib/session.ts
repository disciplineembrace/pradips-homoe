import crypto from 'crypto'
import { cookies } from 'next/headers'

const COOKIE_NAME = 'pin_verified_session'
const MAX_AGE_SECONDS = 60 * 60 * 12 // 12 hours

function getSecret() {
  const secret = process.env.PIN_SESSION_SECRET
  if (!secret || secret.length < 32) {
    throw new Error('PIN_SESSION_SECRET must be at least 32 characters')
  }
  return secret
}

function signPayload(payload: string) {
  return crypto.createHmac('sha256', getSecret()).update(payload).digest('hex')
}

export async function setPinVerifiedSession(userId: string) {
  const cookieStore = await cookies()
  const issuedAt = Math.floor(Date.now() / 1000)
  const payload = `${userId}.${issuedAt}`
  const signature = signPayload(payload)

  cookieStore.set(COOKIE_NAME, `${payload}.${signature}`, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/',
    maxAge: MAX_AGE_SECONDS
  })
}

export async function clearPinVerifiedSession() {
  const cookieStore = await cookies()
  cookieStore.delete(COOKIE_NAME)
}

export async function verifyPinSession(expectedUserId: string) {
  const cookieStore = await cookies()
  const raw = cookieStore.get(COOKIE_NAME)?.value
  if (!raw) return false

  const parts = raw.split('.')
  if (parts.length !== 3) return false

  const [userId, issuedAtRaw, signature] = parts
  if (userId !== expectedUserId) return false

  const issuedAt = Number(issuedAtRaw)
  if (!Number.isFinite(issuedAt)) return false

  const age = Math.floor(Date.now() / 1000) - issuedAt
  if (age < 0 || age > MAX_AGE_SECONDS) return false

  const payload = `${userId}.${issuedAtRaw}`
  const expectedSignature = signPayload(payload)

  try {
    return crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expectedSignature))
  } catch {
    return false
  }
}
