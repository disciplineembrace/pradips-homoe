import { z } from 'zod'

export const loginSchema = z.object({
  email: z.string().email('Enter valid email/login ID'),
  password: z.string().min(6, 'Password is required')
})

export const pinSchema = z.object({
  pin: z.string().regex(/^\d{6}$/, 'PIN must be exactly 6 digits')
})

export const createUserSchema = z.object({
  name: z.string().min(2, 'Name required'),
  email: z.string().email('Valid email required'),
  mobile: z.string().optional(),
  password: z.string().min(8, 'Password must be at least 8 characters'),
  accessPin: z.string().regex(/^\d{6}$/, 'PIN must be exactly 6 digits'),
  role: z.enum(['admin', 'user']),
  status: z.enum(['active', 'blocked']),
  accessExpiry: z.string().optional(),
  deviceLimit: z.coerce.number().int().min(1).max(10).optional()
})

export const updateUserSchema = z.object({
  userId: z.string().uuid(),
  name: z.string().min(2),
  mobile: z.string().optional(),
  role: z.enum(['admin', 'user']),
  status: z.enum(['active', 'blocked']),
  accessExpiry: z.string().optional(),
  deviceLimit: z.coerce.number().int().min(1).max(10).optional()
})

export const changePinSchema = z.object({
  userId: z.string().uuid(),
  accessPin: z.string().regex(/^\d{6}$/, 'PIN must be exactly 6 digits')
})
