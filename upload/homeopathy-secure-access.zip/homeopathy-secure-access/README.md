# Homeopathy Secure Access — Admin + Fixed PIN Login Model

This is a Next.js + Supabase starter model for a private homeopathic remedy website.

## Features

- Admin-created users only
- Email/Login ID + password login
- Fixed 6-digit Access PIN after password login
- PIN is set/reset only by admin
- Users cannot change PIN
- PIN is hashed in database
- 3 wrong PIN attempts -> 15-minute lock
- Admin can unlock/reset PIN
- Admin dashboard/users/logs pages
- Protected remedy reading screen
- Server-side data protection

## Install

```bash
npm install
cp .env.example .env.local
npm run dev
```

## Environment variables

```env
NEXT_PUBLIC_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=your_publishable_or_anon_key
SUPABASE_SECRET_KEY=your_secret_or_service_role_key
PIN_SESSION_SECRET=change-this-long-random-secret-minimum-32-characters
NEXT_PUBLIC_SITE_NAME=Pradip's Homoe
```

## Supabase setup

1. Create Supabase project.
2. Open SQL Editor.
3. Run `supabase/schema.sql`.
4. Create first admin user manually in Supabase Authentication.
5. Insert admin profile in `app_users` with role `admin`.
6. Login with that admin, verify PIN, then create all other users from `/admin/users/create`.

## Important security rules

- Never expose `SUPABASE_SECRET_KEY` to the browser.
- Keep remedy data behind server routes/pages only.
- Do not fetch private remedy data directly from client components.
- Keep RLS enabled.
- Fixed PIN is less secure than real MFA, but acceptable for private controlled access when combined with password, lockout, and admin-only reset.

## Merge into existing website

Copy these parts into your existing Next.js project:

- `lib/`
- `app/actions/`
- `app/login/`
- `app/verify-pin/`
- `app/admin/`
- `middleware.ts`
- SQL schema

Then wrap your existing protected pages with:

```ts
import { requireVerifiedUser } from '@/lib/auth'

export default async function ProtectedPage() {
  await requireVerifiedUser()
  // fetch private data server-side only
}
```

## AI Developer Prompt

Use `AI_DEVELOPER_PROMPT.md` in this folder for Cursor/Lovable/v0.
