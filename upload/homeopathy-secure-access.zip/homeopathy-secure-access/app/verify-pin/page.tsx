import { PinForm } from '@/components/PinForm'
import { requireLoggedInUser } from '@/lib/auth'
import { logoutAction } from '@/app/actions/auth'

export default async function VerifyPinPage() {
  await requireLoggedInUser()
  return (
    <main className="page-center">
      <section className="card">
        <h1>Access PIN</h1>
        <p>Enter the fixed 6-digit PIN given by admin. This is not OTP. It does not resend.</p>
        <PinForm />
        <form action={logoutAction} style={{ marginTop: 14 }}>
          <button className="btn secondary" type="submit">Back to login</button>
        </form>
      </section>
    </main>
  )
}
