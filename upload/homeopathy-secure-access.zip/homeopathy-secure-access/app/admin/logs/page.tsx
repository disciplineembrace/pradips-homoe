import { AdminShell } from '@/components/AdminShell'
import { requireAdmin } from '@/lib/auth'
import { supabaseAdmin } from '@/lib/supabase/admin'

export default async function LogsPage() {
  const { appUser } = await requireAdmin()
  const { data: loginLogs } = await supabaseAdmin.from('login_logs').select('*').order('created_at', { ascending: false }).limit(50)
  const { data: pinLogs } = await supabaseAdmin.from('pin_logs').select('*').order('created_at', { ascending: false }).limit(50)

  return (
    <AdminShell adminName={appUser.name}>
      <h2>Login Logs</h2>
      <div className="table-card" style={{ marginBottom: 28 }}>
        <table>
          <thead><tr><th>Status</th><th>Reason</th><th>IP</th><th>Device</th><th>Time</th></tr></thead>
          <tbody>{(loginLogs || []).map(l => (
            <tr key={l.id}><td>{l.login_status}</td><td>{l.failure_reason || '-'}</td><td>{l.ip_address}</td><td>{String(l.device_info).slice(0,80)}</td><td>{new Date(l.created_at).toLocaleString()}</td></tr>
          ))}</tbody>
        </table>
      </div>
      <h2>PIN Logs</h2>
      <div className="table-card">
        <table>
          <thead><tr><th>Status</th><th>Reason</th><th>IP</th><th>Device</th><th>Time</th></tr></thead>
          <tbody>{(pinLogs || []).map(l => (
            <tr key={l.id}><td>{l.pin_status}</td><td>{l.failure_reason || '-'}</td><td>{l.ip_address}</td><td>{String(l.device_info).slice(0,80)}</td><td>{new Date(l.created_at).toLocaleString()}</td></tr>
          ))}</tbody>
        </table>
      </div>
    </AdminShell>
  )
}
