import Link from 'next/link'
import { AdminShell } from '@/components/AdminShell'
import { requireAdmin } from '@/lib/auth'
import { supabaseAdmin } from '@/lib/supabase/admin'

export default async function UsersPage() {
  const { appUser } = await requireAdmin()
  const { data: users } = await supabaseAdmin.from('app_users').select('*').order('created_at', { ascending: false })

  return (
    <AdminShell adminName={appUser.name}>
      <div className="table-card">
        <table>
          <thead>
            <tr><th>Name</th><th>Email</th><th>Status</th><th>Role</th><th>Expiry</th><th>PIN Attempts</th><th>Last Login</th><th>Action</th></tr>
          </thead>
          <tbody>
            {(users || []).map((u) => (
              <tr key={u.id}>
                <td>{u.name}</td>
                <td>{u.email}</td>
                <td><span className={`badge ${u.status}`}>{u.status}</span></td>
                <td><span className={`badge ${u.role}`}>{u.role}</span></td>
                <td>{u.access_expiry || 'No expiry'}</td>
                <td>{u.pin_failed_attempts || 0}</td>
                <td>{u.last_login ? new Date(u.last_login).toLocaleString() : '-'}</td>
                <td><Link href={`/admin/users/${u.id}`}>Manage</Link></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </AdminShell>
  )
}
