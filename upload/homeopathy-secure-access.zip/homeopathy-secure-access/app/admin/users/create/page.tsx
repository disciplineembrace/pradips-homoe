import { AdminShell } from '@/components/AdminShell'
import { CreateUserForm } from '@/components/CreateUserForm'
import { requireAdmin } from '@/lib/auth'

export default async function CreateUserPage() {
  const { appUser } = await requireAdmin()
  return (
    <AdminShell adminName={appUser.name}>
      <div className="table-card" style={{ padding: 22 }}>
        <h1>Create User</h1>
        <p style={{ color: 'var(--muted)' }}>Set Login ID, password, and fixed 6-digit PIN. User cannot change PIN.</p>
        <CreateUserForm />
      </div>
    </AdminShell>
  )
}
