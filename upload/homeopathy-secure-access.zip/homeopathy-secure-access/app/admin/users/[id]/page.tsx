import { notFound } from 'next/navigation'
import { AdminShell } from '@/components/AdminShell'
import { ChangePinForm, EditUserForm } from '@/components/EditUserForms'
import { deleteUserAction, unlockUserPinAction } from '@/app/actions/admin-users'
import { requireAdmin } from '@/lib/auth'
import { supabaseAdmin } from '@/lib/supabase/admin'

export default async function UserDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { appUser } = await requireAdmin()
  const { id } = await params
  const { data: user } = await supabaseAdmin.from('app_users').select('*').eq('id', id).single()
  if (!user) notFound()

  return (
    <AdminShell adminName={appUser.name}>
      <div className="table-card" style={{ padding: 22 }}>
        <EditUserForm user={user} />
        <ChangePinForm userId={user.id} />
        <div style={{ display: 'flex', gap: 12, marginTop: 28 }}>
          <form action={unlockUserPinAction}>
            <input type="hidden" name="userId" value={user.id} />
            <button className="btn secondary" type="submit">Unlock PIN Attempts</button>
          </form>
          <form action={deleteUserAction}>
            <input type="hidden" name="userId" value={user.id} />
            <button className="btn danger" type="submit">Delete User</button>
          </form>
        </div>
      </div>
    </AdminShell>
  )
}
