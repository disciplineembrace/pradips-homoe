import { AdminShell } from '@/components/AdminShell'
import { requireAdmin } from '@/lib/auth'
import { supabaseAdmin } from '@/lib/supabase/admin'

async function count(table: string, filters?: { column: string; value: string }[]) {
  let query = supabaseAdmin.from(table).select('*', { count: 'exact', head: true })
  filters?.forEach(f => { query = query.eq(f.column, f.value) })
  const { count } = await query
  return count || 0
}

export default async function AdminPage() {
  const { appUser } = await requireAdmin()
  const [total, active, blocked, admins, failedPins] = await Promise.all([
    count('app_users'),
    count('app_users', [{ column: 'status', value: 'active' }]),
    count('app_users', [{ column: 'status', value: 'blocked' }]),
    count('app_users', [{ column: 'role', value: 'admin' }]),
    count('pin_logs', [{ column: 'pin_status', value: 'failed' }])
  ])

  return (
    <AdminShell adminName={appUser.name}>
      <div className="grid-stats">
        <div className="stat"><span>Total Users</span><strong>{total}</strong></div>
        <div className="stat"><span>Active Users</span><strong>{active}</strong></div>
        <div className="stat"><span>Blocked Users</span><strong>{blocked}</strong></div>
        <div className="stat"><span>Admins</span><strong>{admins}</strong></div>
        <div className="stat"><span>Failed PIN Attempts</span><strong>{failedPins}</strong></div>
      </div>
    </AdminShell>
  )
}
