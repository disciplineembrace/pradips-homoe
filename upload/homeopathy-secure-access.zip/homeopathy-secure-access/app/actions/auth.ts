'use server'

import bcrypt from 'bcryptjs'
import { redirect } from 'next/navigation'
import { createClient } from '@/lib/supabase/server'
import { supabaseAdmin } from '@/lib/supabase/admin'
import { clearPinVerifiedSession, setPinVerifiedSession } from '@/lib/session'
import { getAppUser, getCurrentAuthUser, isExpired } from '@/lib/auth'
import { logLogin, logPin } from '@/lib/logs'
import { loginSchema, pinSchema } from '@/lib/validation'

export type ActionState = { ok?: boolean; error?: string }

export async function loginAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const parsed = loginSchema.safeParse({
    email: String(formData.get('email') || '').trim(),
    password: String(formData.get('password') || '')
  })

  if (!parsed.success) return { error: parsed.error.issues[0]?.message || 'Invalid input' }

  const supabase = await createClient()
  const { data, error } = await supabase.auth.signInWithPassword(parsed.data)

  if (error || !data.user) {
    await logLogin(null, 'failed', 'Invalid credentials')
    return { error: 'Login ID or password is wrong.' }
  }

  const appUser = await getAppUser(data.user.id)
  if (!appUser) {
    await supabase.auth.signOut()
    await logLogin(data.user.id, 'failed', 'Profile missing')
    return { error: 'User profile missing. Contact admin.' }
  }

  if (appUser.status === 'blocked') {
    await supabase.auth.signOut()
    await logLogin(data.user.id, 'failed', 'Blocked user')
    return { error: 'Your account has been blocked. Contact admin.' }
  }

  if (isExpired(appUser.access_expiry)) {
    await supabase.auth.signOut()
    await logLogin(data.user.id, 'failed', 'Access expired')
    return { error: 'Your access has expired. Contact admin.' }
  }

  await clearPinVerifiedSession()
  await logLogin(data.user.id, 'success')
  redirect('/verify-pin')
}

export async function verifyPinAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const parsed = pinSchema.safeParse({ pin: String(formData.get('pin') || '').trim() })
  if (!parsed.success) return { error: parsed.error.issues[0]?.message || 'Invalid PIN' }

  const authUser = await getCurrentAuthUser()
  if (!authUser) redirect('/login')

  const appUser = await getAppUser(authUser.id)
  if (!appUser) redirect('/login?error=profile-missing')

  if (appUser.status === 'blocked') return { error: 'Your account has been blocked. Contact admin.' }
  if (isExpired(appUser.access_expiry)) return { error: 'Your access has expired. Contact admin.' }

  if (appUser.pin_locked_until && new Date(appUser.pin_locked_until).getTime() > Date.now()) {
    await logPin(appUser.id, 'locked', 'PIN temporarily locked')
    return { error: 'PIN is temporarily locked for 15 minutes. Contact admin if needed.' }
  }

  const { data: profile, error } = await supabaseAdmin
    .from('app_users')
    .select('access_pin_hash, pin_failed_attempts')
    .eq('id', authUser.id)
    .single()

  if (error || !profile?.access_pin_hash) return { error: 'PIN not configured. Contact admin.' }

  const match = await bcrypt.compare(parsed.data.pin, profile.access_pin_hash)

  if (!match) {
    const nextAttempts = Number(profile.pin_failed_attempts || 0) + 1
    const lockedUntil = nextAttempts >= 3 ? new Date(Date.now() + 15 * 60 * 1000).toISOString() : null

    await supabaseAdmin
      .from('app_users')
      .update({ pin_failed_attempts: nextAttempts, pin_locked_until: lockedUntil })
      .eq('id', authUser.id)

    await logPin(authUser.id, nextAttempts >= 3 ? 'locked' : 'failed', 'Wrong fixed PIN')

    return {
      error: nextAttempts >= 3
        ? 'Wrong PIN. Account PIN verification locked for 15 minutes.'
        : `Wrong PIN. ${3 - nextAttempts} attempt(s) left.`
    }
  }

  await supabaseAdmin
    .from('app_users')
    .update({ pin_failed_attempts: 0, pin_locked_until: null, last_login: new Date().toISOString() })
    .eq('id', authUser.id)

  await setPinVerifiedSession(authUser.id)
  await logPin(authUser.id, 'success')

  if (appUser.role === 'admin') redirect('/admin')
  redirect('/dashboard')
}

export async function logoutAction() {
  const supabase = await createClient()
  await clearPinVerifiedSession()
  await supabase.auth.signOut()
  redirect('/login')
}
