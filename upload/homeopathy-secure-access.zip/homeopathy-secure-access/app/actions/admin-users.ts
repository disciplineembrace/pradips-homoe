'use server'

import bcrypt from 'bcryptjs'
import { redirect } from 'next/navigation'
import { supabaseAdmin } from '@/lib/supabase/admin'
import { requireAdmin } from '@/lib/auth'
import { logPin } from '@/lib/logs'
import { changePinSchema, createUserSchema, updateUserSchema } from '@/lib/validation'
import type { ActionState } from './auth'

export async function createUserAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  await requireAdmin()

  const parsed = createUserSchema.safeParse({
    name: String(formData.get('name') || '').trim(),
    email: String(formData.get('email') || '').trim().toLowerCase(),
    mobile: String(formData.get('mobile') || '').trim() || undefined,
    password: String(formData.get('password') || ''),
    accessPin: String(formData.get('accessPin') || '').trim(),
    role: String(formData.get('role') || 'user'),
    status: String(formData.get('status') || 'active'),
    accessExpiry: String(formData.get('accessExpiry') || '').trim() || undefined,
    deviceLimit: String(formData.get('deviceLimit') || '1')
  })

  if (!parsed.success) return { error: parsed.error.issues[0]?.message || 'Invalid input' }

  const { data: created, error: createError } = await supabaseAdmin.auth.admin.createUser({
    email: parsed.data.email,
    password: parsed.data.password,
    email_confirm: true,
    user_metadata: { name: parsed.data.name }
  })

  if (createError || !created.user) return { error: createError?.message || 'Could not create auth user' }

  const pinHash = await bcrypt.hash(parsed.data.accessPin, 12)

  const { error: profileError } = await supabaseAdmin.from('app_users').insert({
    id: created.user.id,
    name: parsed.data.name,
    email: parsed.data.email,
    mobile: parsed.data.mobile || null,
    access_pin_hash: pinHash,
    role: parsed.data.role,
    status: parsed.data.status,
    access_expiry: parsed.data.accessExpiry || null,
    device_limit: parsed.data.deviceLimit || 1
  })

  if (profileError) {
    await supabaseAdmin.auth.admin.deleteUser(created.user.id)
    return { error: profileError.message }
  }

  redirect('/admin/users?created=1')
}

export async function updateUserAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  await requireAdmin()

  const parsed = updateUserSchema.safeParse({
    userId: String(formData.get('userId') || ''),
    name: String(formData.get('name') || '').trim(),
    mobile: String(formData.get('mobile') || '').trim() || undefined,
    role: String(formData.get('role') || 'user'),
    status: String(formData.get('status') || 'active'),
    accessExpiry: String(formData.get('accessExpiry') || '').trim() || undefined,
    deviceLimit: String(formData.get('deviceLimit') || '1')
  })

  if (!parsed.success) return { error: parsed.error.issues[0]?.message || 'Invalid input' }

  const { error } = await supabaseAdmin
    .from('app_users')
    .update({
      name: parsed.data.name,
      mobile: parsed.data.mobile || null,
      role: parsed.data.role,
      status: parsed.data.status,
      access_expiry: parsed.data.accessExpiry || null,
      device_limit: parsed.data.deviceLimit || 1,
      updated_at: new Date().toISOString()
    })
    .eq('id', parsed.data.userId)

  if (error) return { error: error.message }
  redirect(`/admin/users/${parsed.data.userId}?updated=1`)
}

export async function changeUserPinAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  await requireAdmin()

  const parsed = changePinSchema.safeParse({
    userId: String(formData.get('userId') || ''),
    accessPin: String(formData.get('accessPin') || '').trim()
  })

  if (!parsed.success) return { error: parsed.error.issues[0]?.message || 'Invalid input' }

  const pinHash = await bcrypt.hash(parsed.data.accessPin, 12)

  const { error } = await supabaseAdmin
    .from('app_users')
    .update({
      access_pin_hash: pinHash,
      pin_failed_attempts: 0,
      pin_locked_until: null,
      updated_at: new Date().toISOString()
    })
    .eq('id', parsed.data.userId)

  if (error) return { error: error.message }
  await logPin(parsed.data.userId, 'reset', 'Admin changed fixed PIN')
  redirect(`/admin/users/${parsed.data.userId}?pinChanged=1`)
}

export async function unlockUserPinAction(formData: FormData) {
  await requireAdmin()
  const userId = String(formData.get('userId') || '')
  await supabaseAdmin
    .from('app_users')
    .update({ pin_failed_attempts: 0, pin_locked_until: null, updated_at: new Date().toISOString() })
    .eq('id', userId)
  await logPin(userId, 'reset', 'Admin unlocked PIN')
  redirect(`/admin/users/${userId}?unlocked=1`)
}

export async function deleteUserAction(formData: FormData) {
  await requireAdmin()
  const userId = String(formData.get('userId') || '')
  if (!userId) redirect('/admin/users')
  await supabaseAdmin.from('app_users').delete().eq('id', userId)
  await supabaseAdmin.auth.admin.deleteUser(userId)
  redirect('/admin/users?deleted=1')
}
