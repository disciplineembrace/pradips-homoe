import './globals.css'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: "Pradip's Homoe Secure Access",
  description: 'Private homeopathic remedy reading system with admin-created users and fixed PIN access.'
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
