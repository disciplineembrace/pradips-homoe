import Link from 'next/link'
import { notFound } from 'next/navigation'
import { requireVerifiedUser } from '@/lib/auth'
import { supabaseAdmin } from '@/lib/supabase/admin'

type Remedy = {
  id: string
  name: string
  source: string
  summary: string | null
  content: Record<string, string> | null
}

const sourceTabs = ['Boericke', 'Kent', 'Phatak', 'Murphy', 'Allen', 'Clarke']

export default async function RemedyPage({ params }: { params: Promise<{ id: string }> }) {
  await requireVerifiedUser()
  const { id } = await params
  const { data } = await supabaseAdmin.from('remedies').select('*').eq('id', id).single()
  if (!data) notFound()
  const remedy = data as Remedy
  const sections = remedy.content ? Object.entries(remedy.content) : []

  return (
    <div className="reader-page">
      <header className="reader-topbar">
        <Link href="/dashboard">← Back</Link>
        <strong>{remedy.name}</strong>
        <div style={{ display: 'flex', gap: 12 }}><span>Search</span><span>Bookmark</span><span>⋮</span></div>
      </header>
      <nav className="source-tabs">
        {sourceTabs.map(source => <button key={source} className={source === remedy.source ? 'active' : ''}>{source}</button>)}
      </nav>
      <main className="reader-main">
        <aside className="reader-sidebar">☰<br /><br />⭐<br /><br />📝</aside>
        <article className="remedy-content">
          <h1>{remedy.name}</h1>
          <div className="remedy-meta">{remedy.source} Materia Medica</div>
          {remedy.summary && <p><strong>Summary:</strong> {remedy.summary}</p>}
          {sections.map(([title, text]) => (
            <section key={title} id={title.toLowerCase().replaceAll(' ', '-')}>
              <h2>{title}</h2>
              {String(text).split('\n').filter(Boolean).map((p, i) => <p key={i}>{p}</p>)}
            </section>
          ))}
        </article>
        <aside className="section-index">
          <strong>Sections</strong>
          {sections.map(([title]) => (
            <a key={title} href={`#${title.toLowerCase().replaceAll(' ', '-')}`}>{title}</a>
          ))}
        </aside>
      </main>
      <div className="reader-tools-floating"><button className="fab">＋</button></div>
      <footer className="reader-bottom-bar">
        <span>Previous</span><span>•</span><span>Reading mode</span><span>•</span><span>A− A+</span><span>•</span><span>Next</span>
      </footer>
    </div>
  )
}
