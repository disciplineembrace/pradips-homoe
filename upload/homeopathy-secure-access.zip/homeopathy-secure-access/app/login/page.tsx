import { LoginForm } from '@/components/LoginForm'

function errorText(error?: string) {
  if (error === 'blocked') return 'Your account has been blocked. Contact admin.'
  if (error === 'expired') return 'Your access has expired. Contact admin.'
  if (error === 'profile-missing') return 'User profile missing. Contact admin.'
  return null
}

export default async function LoginPage({ searchParams }: { searchParams: Promise<{ error?: string }> }) {
  const sp = await searchParams
  const message = errorText(sp.error)
  return (
    <main className="page-center">
      <section className="card">
        <h1>{process.env.NEXT_PUBLIC_SITE_NAME || "Pradip's Homoe"}</h1>
        <p>Private remedy access. Login ID and password are created by admin.</p>
        {message && <div className="error">{message}</div>}
        <LoginForm />
      </section>
    </main>
  )
}
