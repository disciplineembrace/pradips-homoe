import Link from 'next/link'
import { requireVerifiedUser } from '@/lib/auth'
import { logoutAction } from '@/app/actions/auth'
import { supabaseAdmin } from '@/lib/supabase/admin'

export default async function DashboardPage() {
  const { appUser } = await requireVerifiedUser()
  const { data: remedies } = await supabaseAdmin.from('remedies').select('id, name, source, summary').order('name').limit(24)

  return (
    <main style={{ padding: 28 }}>
      <div className="admin-top">
        <div>
          <h1 style={{ margin: 0 }}>Remedies</h1>
          <p style={{ color: 'var(--muted)' }}>Welcome, {appUser.name}. Your access is verified.</p>
        </div>
        <form action={logoutAction}><button className="btn secondary">Logout</button></form>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', gap: 16 }}>
        {(remedies || []).map((r) => (
          <Link key={r.id} href={`/remedy/${r.id}`} className="stat">
            <span>{r.source}</span>
            <strong style={{ fontSize: 22 }}>{r.name}</strong>
            <p style={{ color: 'var(--muted)', lineHeight: 1.5 }}>{r.summary}</p>
          </Link>
        ))}
      </div>
    </main>
  )
}
